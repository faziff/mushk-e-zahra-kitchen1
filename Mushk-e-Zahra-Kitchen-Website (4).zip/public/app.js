const state = { menu: [], category: "All", search: "", cart: new Map() };
const $ = (s) => document.querySelector(s);
const money = (n) => `Rs. ${Number(n).toLocaleString("en-PK")}`;
const categorySymbols = {
  "Signature Kabab":"♨", "Desi Handi":"♨", "Rice Kitchen":"✿",
  "Frozen Kitchen":"❄", "Burger & Crunch Corner":"☼", "Snack Attack":"✧"
};
const categoryDescriptions = {
  "Signature Kabab":"Charcoal-kissed favourites",
  "Desi Handi":"Homestyle comfort",
  "Rice Kitchen":"Fragrant and filling",
  "Frozen Kitchen":"Stock up your freezer",
  "Burger & Crunch Corner":"Crunch, bite, delight",
  "Snack Attack":"Little bites, big joy"
};
let toastTimer;
function showToast(message) {
  const el = $("#toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}
async function loadMenu() {
  try {
    const res = await fetch("/api/menu");
    if (!res.ok) throw new Error("Menu unavailable");
    const data = await res.json(); state.menu = data.menu;
    renderCategories(); renderFilters(); renderProducts();
  } catch {
    $("#productGrid").innerHTML = '<div class="empty-state">We couldn’t load the menu. Please refresh and try again.</div>';
  }
}
function renderCategories() {
  const cats = [...new Set(state.menu.map(p => p.category))];
  $("#categoryList").innerHTML = cats.map(c => `<button class="category-chip ${state.category===c?"active":""}" data-category="${escapeAttr(c)}"><span class="cat-symbol">${categorySymbols[c]||"✦"}</span><span>${escapeHtml(c)}</span></button>`).join("");
}
function renderFilters() {
  const cats = ["All", ...new Set(state.menu.map(p => p.category))];
  $("#filterRow").innerHTML = cats.map(c => `<button class="filter-button ${state.category===c?"active":""}" data-category="${escapeAttr(c)}">${escapeHtml(c)}</button>`).join("");
}
function chooseCategory(c) {
  state.category = c; renderCategories(); renderFilters(); renderProducts();
  if (c !== "All") $("#menu").scrollIntoView({ behavior:"smooth", block:"start" });
}
function renderProducts() {
  const filtered = state.menu.filter(p => (state.category==="All" || p.category===state.category) &&
    `${p.name} ${p.category} ${p.description}`.toLowerCase().includes(state.search.toLowerCase()));
  $("#resultsCount").textContent = `${filtered.length} ${filtered.length===1?"dish":"dishes"} to love`;
  if (!filtered.length) {
    $("#productGrid").innerHTML = '<div class="empty-state">No dishes found. Try another search or category.</div>'; return;
  }
  $("#productGrid").innerHTML = filtered.map(p => `
    <article class="product-card">
      <div class="product-image"><img src="${escapeAttr(p.image)}" alt="${escapeAttr(p.name)}" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=700&q=70'"><span class="product-category">${escapeHtml(p.category)}</span></div>
      <div class="product-content"><h3>${escapeHtml(p.name)}</h3><p class="product-description">${escapeHtml(p.description)}</p>
      <div class="product-bottom"><div class="product-price"><strong>${money(p.price)}</strong><small>per ${escapeHtml(p.unit)}</small></div><button class="add-button" data-add="${escapeAttr(p.id)}" aria-label="Add ${escapeAttr(p.name)} to cart">+</button></div></div>
    </article>`).join("");
}
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function escapeAttr(s) { return escapeHtml(s); }
function addItem(id) {
  const p = state.menu.find(x => x.id===id); if (!p) return;
  const current = state.cart.get(id) || 0;
  if (current >= 50) { showToast("Maximum quantity is 50 per item."); return; }
  state.cart.set(id,current+1); updateCart(); showToast(`${p.name} added to your cart`);
}
function changeQty(id,delta) {
  const next=(state.cart.get(id)||0)+delta;
  if(next<=0) state.cart.delete(id); else if(next<=50) state.cart.set(id,next);
  updateCart();
}
function cartItems() {
  return [...state.cart.entries()].map(([id,quantity]) => {
    const p=state.menu.find(x=>x.id===id); return p ? {...p,quantity} : null;
  }).filter(Boolean);
}
function cartTotal() { return cartItems().reduce((s,p)=>s+p.price*p.quantity,0); }
function updateCart() {
  const items=cartItems(), count=items.reduce((s,p)=>s+p.quantity,0), total=cartTotal();
  $("#cartCount").textContent=count; $("#drawerCount").textContent=`(${count})`; $("#cartSubtotal").textContent=money(total); $("#checkoutTotal").textContent=money(total);
  $("#checkoutButton").disabled=!count; $("#checkoutButton").style.opacity=count?"1":".55";
  if(!items.length) $("#cartItems").innerHTML='<div class="cart-empty"><span>♡</span><strong>Your cart is waiting.</strong><p>Pick something delicious from our menu and it’ll show up here.</p></div>';
  else $("#cartItems").innerHTML=items.map(p=>`<div class="cart-item"><div><h3>${escapeHtml(p.name)}</h3><small>${money(p.price)} · ${escapeHtml(p.unit)}</small><div class="quantity-control"><button data-qty="${escapeAttr(p.id)}" data-delta="-1" aria-label="Decrease quantity">−</button><span>${p.quantity}</span><button data-qty="${escapeAttr(p.id)}" data-delta="1" aria-label="Increase quantity">+</button></div></div><div class="cart-item-price">${money(p.price*p.quantity)}</div></div>`).join("");
}
function openCart() {
  $("#cartDrawer").classList.add("open"); $("#overlay").classList.add("open");
  $("#cartDrawer").setAttribute("aria-hidden","false"); document.body.style.overflow="hidden";
}
function closeCart() {
  $("#cartDrawer").classList.remove("open"); $("#overlay").classList.remove("open");
  $("#cartDrawer").setAttribute("aria-hidden","true"); document.body.style.overflow="";
}
function openCheckout() {
  if(!state.cart.size) { showToast("Your cart is empty — choose a dish first."); return; }
  closeCart(); $("#checkoutBackdrop").classList.add("open"); document.body.style.overflow="hidden"; $("#formError").textContent="";
}
function closeCheckout() { $("#checkoutBackdrop").classList.remove("open"); document.body.style.overflow=""; }
document.addEventListener("click", e => {
  const cat=e.target.closest("[data-category]"); if(cat) { chooseCategory(cat.dataset.category); return; }
  const add=e.target.closest("[data-add]"); if(add) { addItem(add.dataset.add); return; }
  const qty=e.target.closest("[data-qty]"); if(qty) { changeQty(qty.dataset.qty,Number(qty.dataset.delta)); return; }
});
$("#searchInput").addEventListener("input", e => { state.search=e.target.value; renderProducts(); });
$("#openCart").addEventListener("click",openCart);
$("#closeCart").addEventListener("click",closeCart);
$("#overlay").addEventListener("click",closeCart);
$("#checkoutButton").addEventListener("click",openCheckout);
$("#closeCheckout").addEventListener("click",closeCheckout);
$("#checkoutBackdrop").addEventListener("click",e=>{if(e.target===$("#checkoutBackdrop"))closeCheckout();});
document.addEventListener("keydown",e=>{if(e.key==="Escape"){closeCart();closeCheckout();}});
$("#checkoutForm").addEventListener("submit", async e => {
  e.preventDefault();
  const form=e.currentTarget, fd=new FormData(form);
  const area=String(fd.get("area")||"").trim();
  const address=[area, String(fd.get("address")||"").trim()].filter(Boolean).join(", ");
  const payload={
    customer:{name:String(fd.get("name")||"").trim(),phone:String(fd.get("phone")||"").trim(),address,instructions:String(fd.get("instructions")||"").trim()},
    items:cartItems().map(p=>({id:p.id,quantity:p.quantity}))
  };
  const btn=$("#placeOrderButton"), err=$("#formError"); err.textContent="";
  btn.disabled=true; btn.innerHTML='Sending your order… <span>♡</span>';
  try {
    const response=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
    const result=await response.json();
    if(!response.ok) throw new Error(result.error||"Could not place order.");
    closeCheckout(); state.cart.clear(); updateCart(); form.reset();
    $("#orderReference").textContent=result.orderId;
    $("#successModal").classList.add("open"); document.body.style.overflow="hidden";
  } catch(error) { err.textContent=error.message||"Something went wrong. Please try again."; }
  finally { btn.disabled=false; btn.innerHTML='Place my order <span>♡</span>'; }
});
$("#doneButton").addEventListener("click",()=>{$("#successModal").classList.remove("open");document.body.style.overflow="";window.scrollTo({top:0,behavior:"smooth"});});
$("#year").textContent=new Date().getFullYear();
updateCart(); loadMenu();
