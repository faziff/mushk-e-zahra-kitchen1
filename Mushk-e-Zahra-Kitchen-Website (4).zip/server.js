require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.join(__dirname, "data");
const ORDERS_FILE = path.join(DATA_DIR, "orders.json");
app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "30kb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/api/orders", rateLimit({ windowMs: 60 * 1000, limit: 12, standardHeaders: true, legacyHeaders: false }));

const MENU = [
  { id:"shami-kabab", name:"Shami Kabab", category:"Signature Kabab", price:90, unit:"piece", description:"Classic homemade shami kabab.", image:"https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"chapli-kabab", name:"Chapli Kabab", category:"Signature Kabab", price:100, unit:"piece", description:"Spiced, pan-seared chapli kabab.", image:"https://images.unsplash.com/photo-1529042410759-befb1204b468?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"seekh-kabab", name:"Seekh Kabab", category:"Signature Kabab", price:100, unit:"piece", description:"Smoky, savory seekh kabab.", image:"https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"alu-ghost", name:"Alu Ghost", category:"Desi Handi", price:250, unit:"plate", description:"Comforting potato and meat curry.", image:"https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"anday-koftay", name:"Anday Koftay", category:"Desi Handi", price:300, unit:"plate", description:"Homestyle koftay with egg.", image:"https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"achaar-ghost", name:"Achaar Ghost", category:"Desi Handi", price:300, unit:"plate", description:"Tangy achari-style curry.", image:"https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"chinese-rice", name:"Chinese Rice", category:"Rice Kitchen", price:350, unit:"plate", description:"Flavorful rice with a Chinese-inspired twist.", image:"https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"chicken-roasted-biryani", name:"Chicken Roasted Biryani", category:"Rice Kitchen", price:350, unit:"plate", description:"Aromatic biryani with roasted chicken.", image:"https://images.unsplash.com/photo-1563379091339-03246963d96c?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"chicken-bombay-biryani", name:"Chicken Bombay Biryani", category:"Rice Kitchen", price:350, unit:"plate", description:"Spicy, fragrant Bombay-style biryani.", image:"https://images.unsplash.com/photo-1633945274405-b6c8069047b0?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"chicken-sindhi-biryani", name:"Chicken Sindhi Biryani", category:"Rice Kitchen", price:350, unit:"plate", description:"Bold Sindhi biryani spices and aroma.", image:"https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"chicken-yakhni-pulao", name:"Chicken Yakhni Pulao", category:"Rice Kitchen", price:350, unit:"plate", description:"Fragrant pulao cooked in savory yakhni.", image:"https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"frozen-paratha", name:"Frozen Paratha", category:"Frozen Kitchen", price:250, unit:"5-piece pack", description:"Ready-to-cook frozen parathas · pack of 5.", image:"https://images.unsplash.com/photo- m8Q?auto=format&fit=crop&w=700&q=75", vegetarian:true },
  { id:"alu-paratha", name:"Alu Paratha", category:"Frozen Kitchen", price:500, unit:"5-piece pack", description:"Frozen potato parathas · pack of 5.", image:"https://images.unsplash.com/photo-1626200419199-391ae4be7a41?auto=format&fit=crop&w=700&q=75", vegetarian:true },
  { id:"frozen-shami-kabab", name:"Frozen Shami Kabab", category:"Frozen Kitchen", price:500, unit:"6-piece pack", description:"Homemade frozen shami kabab · pack of 6.", image:"https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"frozen-chapli-kabab", name:"Frozen Chapli Kabab", category:"Frozen Kitchen", price:600, unit:"6-piece pack", description:"Frozen chapli kabab · pack of 6.", image:"https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"frozen-chicken-samosa", name:"Frozen Chicken Samosa", category:"Frozen Kitchen", price:300, unit:"6-piece pack", description:"Frozen chicken samosas · pack of 6.", image:"https://images.unsplash.com/photo-1601050690117-94f5f6fa8bd7?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"double-anda-shami-burger", name:"Double Anda Shami Burger", category:"Burger & Crunch Corner", price:350, unit:"burger", description:"A filling shami burger with double egg.", image:"https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"anda-shami-burger", name:"Anda Shami Burger", category:"Burger & Crunch Corner", price:310, unit:"burger", description:"Classic anda shami burger.", image:"https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"fresh-fries", name:"Fresh Fries", category:"Burger & Crunch Corner", price:150, unit:"box", description:"Golden, crispy fries · one box.", image:"https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=700&q=75", vegetarian:true },
  { id:"crispy-nuggets", name:"Crispy Nuggets", category:"Burger & Crunch Corner", price:210, unit:"6-piece pack", description:"Crispy chicken nuggets · 6 pieces.", image:"https://images.unsplash.com/photo-1562967-8c8f4e7f6d0b?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"chicken-macaroni-half", name:"Chicken Macaroni", category:"Burger & Crunch Corner", price:250, unit:"half plate", description:"Homestyle chicken macaroni · half plate.", image:"https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"chicken-macaroni-full", name:"Chicken Macaroni", category:"Burger & Crunch Corner", price:500, unit:"full plate", description:"Homestyle chicken macaroni · full plate.", image:"https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"malai-botti-samosa", name:"Malai Botti Samosa", category:"Snack Attack", price:300, unit:"6-piece pack", description:"Creamy malai boti-inspired samosas · 6 pieces.", image:"https://images.unsplash.com/photo-1601050690117-94f5f6fa8bd7?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"pizza-samosa", name:"Pizza Samosa", category:"Snack Attack", price:300, unit:"6-piece pack", description:"Pizza-flavored samosas · 6 pieces.", image:"https://images.unsplash.com/photo-1601050690117-94f5f6fa8bd7?auto=format&fit=crop&w=700&q=75", vegetarian:false },
  { id:"mix-vegetable-samosa", name:"Mix Vegetable Samosa", category:"Snack Attack", price:300, unit:"6-piece pack", description:"Vegetable samosas · 6 pieces.", image:"https://images.unsplash.com/photo-1601050690117-94f5f6fa8bd7?auto=format&fit=crop&w=700&q=75", vegetarian:true },
  { id:"macaroni-samosa", name:"Macaroni Samosa", category:"Snack Attack", price:300, unit:"6-piece pack", description:"Crunchy macaroni-filled samosas · 6 pieces.", image:"https://images.unsplash.com/photo-1601050690117-94f5f6fa8bd7?auto=format&fit=crop&w=700&q=75", vegetarian:true },
  { id:"chicken-samosa", name:"Chicken Samosa", category:"Snack Attack", price:300, unit:"6-piece pack", description:"Chicken samosas · 6 pieces.", image:"https://images.unsplash.com/photo-1601050690117-94f5f6fa8bd7?auto=format&fit=crop&w=700&q=75", vegetarian:false }
];
// Replace accidental placeholder URL with a valid photo fallback.
MENU.find(x => x.id === "frozen-paratha").image = "https://images.unsplash.com/photo-1626200419199-391ae4be7a41?auto=format&fit=crop&w=700&q=75";

app.get("/api/menu", (_req, res) => res.json({ menu: MENU, currency: "PKR" }));

function validateOrder(body) {
  if (!body || typeof body !== "object") return "Invalid order.";
  const name = String(body.customer?.name || "").trim();
  const phone = String(body.customer?.phone || "").trim();
  const address = String(body.customer?.address || "").trim();
  if (name.length < 2 || name.length > 80) return "Please enter your full name.";
  if (phone.replace(/\D/g, "").length < 7 || phone.length > 30) return "Please enter a valid phone number.";
  if (address.length < 8 || address.length > 400) return "Please enter a complete delivery address.";
  if (!Array.isArray(body.items) || body.items.length < 1 || body.items.length > 60) return "Your cart is empty or too large.";
  for (const item of body.items) {
    if (!MENU.some(p => p.id === item.id)) return "An item in your cart is not available.";
    if (!Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > 50) return "Invalid item quantity.";
  }
  return null;
}

async function sendWhatsAppNotification(order) {
  const { WHATSAPP_TOKEN, WHATSAPP_PHONE_NUMBER_ID, WHATSAPP_TO_NUMBER, WHATSAPP_API_VERSION = "v22.0" } = process.env;
  if (!WHATSAPP_TOKEN || !WHATSAPP_PHONE_NUMBER_ID || !WHATSAPP_TO_NUMBER) {
    return { sent: false, reason: "WhatsApp credentials are not configured yet." };
  }
  const lines = [
    "🍽️ *NEW ORDER — Mushk e Zahra Kitchen*",
    `Order: ${order.id}`,
    `Customer: ${order.customer.name}`,
    `Phone: ${order.customer.phone}`,
    `Address: ${order.customer.address}`,
    order.customer.instructions ? `Instructions: ${order.customer.instructions}` : "",
    "",
    "*Items:*",
    ...order.items.map(i => `• ${i.name} × ${i.quantity} (${i.unit}) — Rs. ${(i.price * i.quantity).toLocaleString("en-PK")}`),
    "",
    `*TOTAL: Rs. ${order.total.toLocaleString("en-PK")}*`,
    `Placed: ${new Date(order.createdAt).toLocaleString("en-PK", { timeZone: "Asia/Karachi" })}`
  ].filter(Boolean);
  const response = await fetch(`https://graph.facebook.com/${WHATSAPP_API_VERSION}/${WHATSAPP_PHONE_NUMBER_ID}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${WHATSAPP_TOKEN}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: WHATSAPP_TO_NUMBER.replace(/\D/g, ""),
      type: "text",
      text: { preview_url: false, body: lines.join("\n") }
    })
  });
  if (!response.ok) {
    const detail = await response.text();
    console.error("WhatsApp API error:", detail);
    return { sent: false, reason: "WhatsApp provider rejected the message." };
  }
  return { sent: true };
}

app.post("/api/orders", async (req, res) => {
  const error = validateOrder(req.body);
  if (error) return res.status(400).json({ error });
  const products = new Map(MENU.map(p => [p.id, p]));
  const items = req.body.items.map(i => {
    const p = products.get(i.id);
    return { id: p.id, name: p.name, category: p.category, price: p.price, unit: p.unit, quantity: i.quantity };
  });
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const order = {
    id: "MZ-" + Date.now().toString(36).toUpperCase(),
    createdAt: new Date().toISOString(),
    status: "received",
    customer: {
      name: String(req.body.customer.name).trim(),
      phone: String(req.body.customer.phone).trim(),
      address: String(req.body.customer.address).trim(),
      instructions: String(req.body.customer.instructions || "").trim().slice(0, 300)
    },
    items, total
  };
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    const orders = fs.existsSync(ORDERS_FILE) ? JSON.parse(fs.readFileSync(ORDERS_FILE, "utf8")) : [];
    orders.push(order);
    fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2));
  } catch (e) {
    console.error("Could not save order:", e);
    return res.status(500).json({ error: "We couldn't save your order. Please try again." });
  }
  const whatsapp = await sendWhatsAppNotification(order).catch(err => {
    console.error("WhatsApp notification failed:", err);
    return { sent: false, reason: "Notification could not be sent." };
  });
  // The order is saved even if WhatsApp is not configured. Do not expose credentials/provider details.
  return res.status(201).json({ ok: true, orderId: order.id, total, notification: whatsapp.sent ? "sent" : "pending_setup" });
});

// Basic owner-only order list. Set ADMIN_KEY in .env and send it as x-admin-key.
app.get("/api/admin/orders", (req, res) => {
  const key = process.env.ADMIN_KEY;
  if (!key || key.length < 20 || req.get("x-admin-key") !== key) return res.status(401).json({ error: "Unauthorized" });
  try {
    const orders = fs.existsSync(ORDERS_FILE) ? JSON.parse(fs.readFileSync(ORDERS_FILE, "utf8")) : [];
    res.json({ orders: orders.slice(-200).reverse() });
  } catch {
    res.status(500).json({ error: "Could not read orders." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`Mushk e Zahra Kitchen running at http://localhost:${PORT}`));
