# Mushk e Zahra Kitchen — Full-stack ordering website

A responsive food ordering site with a lightweight Node.js/Express backend, server-validated pricing, order storage, and optional WhatsApp Cloud API notifications.

## Features

- Responsive mobile, tablet and desktop design
- Search and filter across the provided menu
- Cart quantity controls and live totals
- Checkout form for name, phone, address, optional area and instructions
- Backend validates menu item IDs and recalculates prices (the browser cannot set prices)
- Orders saved to `data/orders.json`
- Optional owner WhatsApp notification through Meta WhatsApp Cloud API
- Simple API-protected order listing at `/api/admin/orders`
- Lightweight image loading (`loading="lazy"`) and no frontend framework/build step

## Menu

Menu and prices are entered from the supplied Mushk e Zahra Kitchen menu image. Prices are in PKR. Confirm all prices and pack sizes before publishing; the menu image is the source used for this starter.

## Run locally

1. Install Node.js 18 or newer.
2. Extract the ZIP and open a terminal in this folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Create your local environment file:
   - Windows PowerShell: `Copy-Item .env.example .env`
   - macOS/Linux: `cp .env.example .env`
5. Edit `.env`; set `ADMIN_KEY` to a long random value. WhatsApp fields can remain blank while testing.
6. Start the server:
   ```bash
   npm start
   ```
7. Visit `http://localhost:3000`.

Orders placed locally are saved in `data/orders.json`. Do not delete or expose this file: it contains customer information.

## Enable WhatsApp owner notifications

This project sends a WhatsApp **Cloud API text message to the owner-configured receiving number** after an order is saved. Customers are not redirected to WhatsApp and are not asked to message the owner manually.

In `.env`, set:

- `WHATSAPP_TOKEN`: Meta WhatsApp Cloud API access token
- `WHATSAPP_PHONE_NUMBER_ID`: the sending WhatsApp Business phone-number ID from Meta
- `WHATSAPP_TO_NUMBER`: owner's receiving number in international format, digits only, e.g. `923001234567`
- `WHATSAPP_API_VERSION`: supported Graph API version, default `v22.0`

The sending number must be configured in Meta's WhatsApp Business Platform and permitted to send to the receiving number. For production use, follow Meta's current business verification, recipient opt-in, template and messaging-window rules. Keep the token only on the server in `.env`; never put it in frontend JavaScript. Restart the server after editing `.env`.

If credentials are not set, orders are still saved and the website confirms the order, but the WhatsApp notification remains pending setup. Check server logs for provider errors.

## Admin order endpoint

Request `GET /api/admin/orders` with header `x-admin-key: YOUR_ADMIN_KEY`. The endpoint returns up to the most recent 200 orders. Use HTTPS in production and do not share the admin key. For a public production deployment, add proper admin authentication, database backups, retention/deletion policies and access logging.

## Before going live

- Add your real WhatsApp Cloud API credentials.
- Verify every menu item, price, serving/pack size, and food photo.
- Configure HTTPS and a persistent database/storage. The included JSON file storage is suitable for a small demo or a single server, not multi-instance production hosting.
- Add your confirmed delivery fee, service area, hours, cancellation policy and payment options if needed. No address or delivery fee has been invented here.
- Set up backups and protect customer data.
- Use a persistent hosting service; a temporary/local computer must remain online for the server to receive orders.

## API overview

- `GET /api/menu` — public menu
- `POST /api/orders` — validates and stores an order, then attempts WhatsApp notification
- `GET /api/admin/orders` — requires `x-admin-key`

## Notes

Food images are loaded from Unsplash URLs and require an internet connection. Replace them with optimized, licensed restaurant-specific photos when available. The site intentionally does not display a restaurant address or pretend WhatsApp notifications work before credentials are configured.
